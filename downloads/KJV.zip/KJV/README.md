# README

## THE HOLY BIBLE, Containing The Old Testament and The New.

The King James Version or Authorized Version of the Holy Bible (1769), with Apocrypha.

In this ZIP archive, you will find the following files:
* This README.md markdown file.
* KJV.txt, which is a text file containing the canonical 66 books of the Bible.
* A folder named Books with the following contents:
  * A folder named Apocrypha containing a text file that contains the text of the Apocryphal books.
  * 66 text files, one for each canonical book of the Bible, containing the text of their respective book.

The text has not been modified.

## Copyright

From Wikipedia: "The Authorized Version is in the public domain in most of the world. In the United Kingdom, the right to print, publish and distribute it is a royal prerogative and the Crown licenses publishers to reproduce it under letters patent. In England, Wales and Northern Ireland the letters patent are held by the King's Printer, and in Scotland by the Scottish Bible Board."

Source: https://en.wikipedia.org/wiki/King_James_Version#Copyright_status

Residents of the United Kingdom, please read this Rights and Permissions page on the Cambridge website: https://www.cambridge.org/bibles/about/rights-and-permissions/rights-and-permissions-kjv
